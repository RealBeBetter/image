 /**
 * @author Real
 * @since ${DATE} ${TIME}
 */
package main

func main() {
	#[[$END$]]#
}
